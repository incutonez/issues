export {default as MyImage} from "@/MyImage.vue"
export {default as MyImage2} from "@/MyImage2.vue"